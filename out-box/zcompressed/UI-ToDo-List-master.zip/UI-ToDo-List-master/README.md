## What it that ? UI To-Do-List APP.
### DEMO: [https://karim-muhammad.github.io/UI-ToDo-List/]

### coming features:
- Adding Focus on Button Sweet Alert

- add algorithm to know index of specfic element to remove
from array

- prevent whitespace in begining input

- add modify button

- add Delete All

- Done All Tasks

- add Done Button

- Add Tasks to Local Storage
