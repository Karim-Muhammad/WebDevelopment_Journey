# Storage_list

demo :  https://karim-muhammad.github.io/Storage_list/

but it has a bad Arcitecture for build IDs and Order things
__________

### * Updates Should be for *
- Order Tasks in LocalStorage and is at least sense for Programmer to understand it
