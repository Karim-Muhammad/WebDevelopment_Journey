# localStorage_ex

#### demo: [https://karim-muhammad.github.io/localStorage_ex/]
