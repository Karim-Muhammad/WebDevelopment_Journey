let bar = document.querySelector(".menu");
let links = document.querySelector(".links");
bar.addEventListener("click", ()=> {
    bar.classList.toggle("active");
})