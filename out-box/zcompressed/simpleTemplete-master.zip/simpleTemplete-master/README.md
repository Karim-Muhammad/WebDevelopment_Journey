# simpleTemplete
#### demo: [https://karim-muhammad.github.io/simpleTemplete/]
***Application on HTML, CSS and Responsive design***
SO simple templete
thanks

