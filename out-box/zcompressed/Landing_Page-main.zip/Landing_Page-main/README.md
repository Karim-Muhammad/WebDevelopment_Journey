Description
=======
Making Landing Page by using HTML, CSS, JavaScript.

features
------------
1. Dynamic Navbar for Sections, responsive as well.
  * made of JavaScript.
  * CSS (Media Query).
2. Button to Create New Section
  * made of JavaScript.

#### List of what software, firmware and hardware you may require.
you **need** only website, Available Internet.

List of files included in the project.
=======
  1. HTML => index.html.
  2. CSS => css.css.
  3. JavaScript => app.js.

**Copyright and licensing information.**
  Source: **Udacity**.
Acknowledgements and credits for any resources or blogs that helped you create the project.
  First Thank for Udacity and tutors there!
  ![Udacity](https://img.shields.io/badge/Udacity-grey?style=for-the-badge&logo=udacity&logoColor=15B8E6)
  and the rest resources which mentioned by their like:
  1. GeeksforGeeks.
  2. W3School.
  3. MDN reference.
  4. StackOverFlow.

##### [Known bugs].
Responsive not perfect(block form) , smooth behavior, make sure you enable in chrome://flags **smooth scroll** in your browser.
  
##### [Solved Bugs].
 div.ScrollTop event click works now solved by: => using z-index: 1000;
