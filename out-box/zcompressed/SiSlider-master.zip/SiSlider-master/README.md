# About: So Simple Slider

##### DEMO: [https://karim-muhammad.github.io/SiSlider/]
