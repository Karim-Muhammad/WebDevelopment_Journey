Try : [https://karim-muhammad.github.io/memory_game/]
# Memory Game
##  Design Simple Memory Game v1
### Features in come 
- Popup Box appear result of Player
- Box re-play again
- ~~Adding Sounds in game~~
- Adding Dashboard Leadership
- Storing data's Game in localStorage

> The Life is a simple
> but we carry more and more
## Tech

Technology is used:

- [HTML] - Structure of Game!
- [CSS] - Styling of Game
- [Javascript] - Add Behaviour.
